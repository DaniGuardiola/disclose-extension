# remove old dist dir
rm -r dist-extension

# build code
yarn build

# copy extension files
cp -r ext-files dist-extension

# copy built code files
cp -r dist dist-extension/js